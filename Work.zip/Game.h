#ifndef GAME_H
#define GAME_H

#include "Board.h"

class Game {
private:
    Board board;
    Color currentPlayer;

public:
    Game(int width, int height);
    void playTurn(int x, int y);
    bool checkWin();
    void switchPlayer();
    Color getCurrentPlayer() const; // Метод для получения текущего игрока
    void display() const; // Метод для отображения доски
};

#endif // GAME_H