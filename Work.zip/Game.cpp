#include <iostream>
#include "Game.h"

using namespace std;

Game::Game(int width, int height) : board(width, height), currentPlayer(Color::PLAYER1) {}

void Game::playTurn(int x, int y) {
    if (board.placePoint(x, y, currentPlayer)) {
        cout << "Игрок " << (currentPlayer == Color::PLAYER1 ? "1" : "2") << " поставил точку в (" << x << ", " << y << ")." << endl;
    } else {
        cout << "Неверный ход! Попробуйте ещё раз." << endl;
    }
}

bool Game::checkWin() {
    int surroundedPoints = board.countSurroundedPoints(currentPlayer == Color::PLAYER1 ? Color::PLAYER2 : Color::PLAYER1);
    return surroundedPoints >= 1;
}

void Game::switchPlayer() {
    currentPlayer = (currentPlayer == Color::PLAYER1) ? Color::PLAYER2 : Color::PLAYER1;
}

Color Game::getCurrentPlayer() const {
    return currentPlayer;
}

void Game::display() const {
    board.display();
}

