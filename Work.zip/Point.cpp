#include "Point.h"

Point::Point(int x, int y, Color color) : x(x), y(y), color(color) {}

int Point::getX() const {
    return x;
}

int Point::getY() const {
    return y;
}

Color Point::getColor() const {
    return color;
}