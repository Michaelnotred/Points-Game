#include <iostream>
#include "Game.h"
using namespace std;

int main() {
    Game game(10, 10);
    int x, y;

    while (true) {
        cout << "Текущее поле:" << endl;
        game.display();

        cout << "Игрок " << (game.getCurrentPlayer() == Color::PLAYER1 ? "1 (X)" : "2 (O)") << ", введите координаты вашей точки (x y) или -1 для выхода: ";
        cin >> x;

        if (x == -1) {
            cout << "Игра завершена." << endl;
            break;
        }

        cin >> y;

        game.playTurn(x, y);

        if (game.checkWin()) {
            cout << "Игрок " << (game.getCurrentPlayer() == Color::PLAYER1 ? "2" : "1") << " выиграл!" << endl;
            game.display();
            break;
        }

        game.switchPlayer();
    }

    return 0;
}

