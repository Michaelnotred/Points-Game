#ifndef POINT_H
#define POINT_H

enum class Color {
    NONE,
    PLAYER1,
    PLAYER2
};

class Point {
private:
    int x;
    int y;
    Color color;

public:
    Point(int x, int y, Color color);
    int getX() const;
    int getY() const;
    Color getColor() const;
};

#endif