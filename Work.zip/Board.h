#ifndef BOARD_H
#define BOARD_H

#include <vector>
#include "Point.h"

class Board {
private:
    int width;
    int height;
    std::vector<std::vector<Color>> grid;
    bool isSurrounded(int x, int y, Color opponentColor) const; // Объявление функции

public:
    Board(int width, int height);
    bool placePoint(int x, int y, Color color);
    void display() const;
    int countSurroundedPoints(Color color) const;
};

#endif // BOARD_H

