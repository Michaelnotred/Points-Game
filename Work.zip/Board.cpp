#include <iostream>
#include "Board.h"

using namespace std;

Board::Board(int width, int height) : width(width), height(height) {
    grid.resize(height, vector<Color>(width, Color::NONE));
}

bool Board::placePoint(int x, int y, Color color) {
    if (x >= 0 && x < width && y >= 0 && y < height && grid[y][x] == Color::NONE) {
        grid[y][x] = color;
        return true;
    }
    return false;
}

void Board::display() const {
    for (int y = 0; y < height; ++y) {
        for (int x = 0; x < width; ++x) {
            char displayChar = '.';
            if (grid[y][x] == Color::PLAYER1) {
                displayChar = 'X';
            } else if (grid[y][x] == Color::PLAYER2) {
                displayChar = 'O';
            }
            cout << displayChar << ' ';
        }
        cout << endl;
    }
}

int Board::countSurroundedPoints(Color color) const {
    int count = 0;
    for (int y = 0; y < height; ++y) {
        for (int x = 0; x < width; ++x) {
            if (grid[y][x] != color && grid[y][x] != Color::NONE) {
                if (isSurrounded(x, y, color)) {
                    count++;
                }
            }
        }
    }
    return count;
}

bool Board::isSurrounded(int x, int y, Color opponentColor) const {
    if (x <= 0 || x >= width -1 || y <= 0 || y >= height -1) return false;
    bool surrounded = true;
    for (int dx = -1; dx <= 1; ++dx) {
        for (int dy = -1; dy <= 1; ++dy) {
            if (abs(dx) + abs(dy) != 1) continue; 
            if (grid[y + dy][x + dx] != opponentColor) {
                surrounded = false;
                break;
            }
        }
        if (!surrounded) break;
    }
    return surrounded;
}

